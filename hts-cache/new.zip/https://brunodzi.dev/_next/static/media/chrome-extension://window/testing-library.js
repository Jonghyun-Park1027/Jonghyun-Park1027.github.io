<!doctype html>
<!-- https://vercel.app -->
<h1>Redirecting (308)</h1>
<a>/_next/static/media/chrome-extension:/window/testing-library.js</a>
